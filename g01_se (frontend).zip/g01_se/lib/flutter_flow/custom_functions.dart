import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/backend.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';
import '/auth/firebase_auth/auth_util.dart';

double calculateDrugConcentration(
  double weight,
  List<int> doseTimestamps,
  int currentTime,
) {
  // MPH 약물 농도 계산 (ng/mL)
  // 기본 설정
  const double refWt = 70.0;
  const double vpop = 73.0;
  const double clPop = 13.2;
  const double fabs = 0.0585;
  const double dose = 18.0;

  // 분획 설정
  const double fi = 0.65;
  const double fer = 1 - fi;

  // 흡수 속도 및 지연 시간
  const double ka1 = 0.25;
  const double ka2 = 0.16;
  const double tlag = 5.75;

  // 체중 기반 스케일링
  final double w = weight > 0 ? weight : refWt;
  final double v = vpop * (w / refWt);
  final double cl = clPop * math.pow(w / refWt, 0.75);
  final double k = cl / v;

  // 시간 기준
  final int nowSec = currentTime > 0
      ? currentTime
      : (DateTime.now().millisecondsSinceEpoch ~/ 1000);

  // 누적 농도 계산
  double totMgL = 0.0;

  for (int i = 0; i < doseTimestamps.length; i++) {
    final int doseSec = doseTimestamps[i];
    if (doseSec <= 0) continue;

    final double t = (nowSec - doseSec) / 3600.0;
    if (t <= 0) continue;

    // IR 부분
    final double cIr = (fabs * dose * fi * ka1) /
        (v * (ka1 - k)) *
        (math.exp(-k * t) - math.exp(-ka1 * t));

    // ER 부분
    double cEr = 0.0;
    if (t >= tlag) {
      final double dt = t - tlag;
      cEr = (fabs * dose * fer * ka2) /
          (v * (ka2 - k)) *
          (math.exp(-k * dt) - math.exp(-ka2 * dt));
    }
    totMgL += cIr + cEr;
  }

  return totMgL * 1000; // mg/L → ng/mL
}

double getScaledVolume(double weight) {
  // 체중 기반 분포용적 계산 (L)
  const double refWt = 70.0;
  const double vpop = 73.0;
  final double w = weight > 0 ? weight : refWt;
  return vpop * (w / refWt);
}

double getScaledClearance(double weight) {
  // 체중 기반 클리어런스 계산 (L/h)
  const double refWt = 70.0;
  const double clPop = 13.2;
  final double w = weight > 0 ? weight : refWt;
  return clPop * math.pow(w / refWt, 0.75);
}

double getEliminationRate(double weight) {
  // 제거속도 상수 계산 (1/h)
  final double v = getScaledVolume(weight);
  final double cl = getScaledClearance(weight);
  return cl / v;
}

double getDrugHalfLife(double weight) {
  // 약물 반감기 계산 (시간)
  final double k = getEliminationRate(weight);
  return 0.693 / k;
}

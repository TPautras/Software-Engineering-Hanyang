import 'package:flutter/material.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {}

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  List<int> _doseList = [];
  List<int> get doseList => _doseList;
  set doseList(List<int> value) {
    _doseList = value;
  }

  void addToDoseList(int value) {
    doseList.add(value);
  }

  void removeFromDoseList(int value) {
    doseList.remove(value);
  }

  void removeAtIndexFromDoseList(int index) {
    doseList.removeAt(index);
  }

  void updateDoseListAtIndex(
    int index,
    int Function(int) updateFn,
  ) {
    doseList[index] = updateFn(_doseList[index]);
  }

  void insertAtIndexInDoseList(int index, int value) {
    doseList.insert(index, value);
  }

  int _loopIndes = 0;
  int get loopIndes => _loopIndes;
  set loopIndes(int value) {
    _loopIndes = value;
  }
}

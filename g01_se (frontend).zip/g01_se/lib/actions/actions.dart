import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/schema/enums/enums.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';

Future updateConcentrationsBytime(BuildContext context) async {
  UsersRecord? healthInfo;
  List<DoseRecord>? dosequery;
  List<ConcentrationsRecord>? concentrationsQuery;
  ConcentrationsRecord? updateConcentrations;

  final firestoreBatch = FirebaseFirestore.instance.batch();
  try {
    if ((valueOrDefault(currentUserDocument?.weight, 0.0) == null) ||
        (valueOrDefault(currentUserDocument?.weight, 0.0) == 0.0)) {
      logFirebaseEvent('updateConcentrationsBytime_alert_dialog');
      await showDialog(
        context: context,
        builder: (alertDialogContext) {
          return AlertDialog(
            content:
                Text('Please enter your weight to calculate medicine effect '),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(alertDialogContext),
                child: Text('Ok'),
              ),
            ],
          );
        },
      );
      logFirebaseEvent('updateConcentrationsBytime_navigate_to');

      context.pushNamed(EditUserBodyInfoWidget.routeName);

      return;
    }
    logFirebaseEvent('updateConcentrationsBytime_backend_call');
    healthInfo = await UsersRecord.getDocumentOnce(currentUserReference!);
    logFirebaseEvent('updateConcentrationsBytime_firestore_que');
    dosequery = await queryDoseRecordOnce(
      queryBuilder: (doseRecord) =>
          doseRecord.orderBy('doseTimestamp', descending: true),
      limit: 24,
    );
    logFirebaseEvent('updateConcentrationsBytime_firestore_que');
    concentrationsQuery = await queryConcentrationsRecordOnce(
      queryBuilder: (concentrationsRecord) => concentrationsRecord
          .where(
            'user',
            isEqualTo: currentUserReference,
          )
          .where(
            'timestamp',
            isGreaterThanOrEqualTo: getCurrentTimestamp,
          ),
    );
    while (FFAppState().loopIndes < concentrationsQuery!.length) {
      logFirebaseEvent('updateConcentrationsBytime_backend_call');
      firestoreBatch.delete(concentrationsQuery!
          .elementAtOrNull(FFAppState().loopIndes)!
          .reference);
      logFirebaseEvent('updateConcentrationsBytime_update_app_st');
      FFAppState().loopIndes = FFAppState().loopIndes + 1;
    }
    logFirebaseEvent('updateConcentrationsBytime_update_app_st');
    FFAppState().loopIndes = 0;
    for (int loop1Index = 0;
        loop1Index < FFAppConstants.timeList.length;
        loop1Index++) {
      final currentLoop1Item = FFAppConstants.timeList[loop1Index];
      logFirebaseEvent('updateConcentrationsBytime_backend_call');

      var concentrationsRecordReference = ConcentrationsRecord.collection.doc();
      firestoreBatch.set(
          concentrationsRecordReference,
          createConcentrationsRecordData(
            timestamp: dateTimeFromSecondsSinceEpoch(
                getCurrentTimestamp.secondsSinceEpoch +
                    60 * 60 * currentLoop1Item),
            concentration: functions.calculateDrugConcentration(
                healthInfo!.weight,
                dosequery!
                    .map((e) => e.doseTimestamp?.secondsSinceEpoch)
                    .withoutNulls
                    .toList()
                    .toList(),
                dateTimeFromSecondsSinceEpoch(
                        getCurrentTimestamp.secondsSinceEpoch +
                            60 * 60 * currentLoop1Item)
                    .secondsSinceEpoch),
            user: currentUserReference,
          ));
      updateConcentrations = ConcentrationsRecord.getDocumentFromData(
          createConcentrationsRecordData(
            timestamp: dateTimeFromSecondsSinceEpoch(
                getCurrentTimestamp.secondsSinceEpoch +
                    60 * 60 * currentLoop1Item),
            concentration: functions.calculateDrugConcentration(
                healthInfo!.weight,
                dosequery!
                    .map((e) => e.doseTimestamp?.secondsSinceEpoch)
                    .withoutNulls
                    .toList()
                    .toList(),
                dateTimeFromSecondsSinceEpoch(
                        getCurrentTimestamp.secondsSinceEpoch +
                            60 * 60 * currentLoop1Item)
                    .secondsSinceEpoch),
            user: currentUserReference,
          ),
          concentrationsRecordReference);
    }
  } finally {
    await firestoreBatch.commit();
  }
}

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyBuJppFvsosSEmvncl6iKvDsAOqbj6SdpA",
            authDomain: "swengineering-34e0a.firebaseapp.com",
            projectId: "swengineering-34e0a",
            storageBucket: "swengineering-34e0a.firebasestorage.app",
            messagingSenderId: "273063935726",
            appId: "1:273063935726:web:f2cd72c3daf34a98b37dff",
            measurementId: "G-YE9Q33212G"));
  } else {
    await Firebase.initializeApp();
  }
}

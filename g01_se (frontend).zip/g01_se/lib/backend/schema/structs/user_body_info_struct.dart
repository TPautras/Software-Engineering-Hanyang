// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class UserBodyInfoStruct extends FFFirebaseStruct {
  UserBodyInfoStruct({
    Gender? gender,
    double? weight,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _gender = gender,
        _weight = weight,
        super(firestoreUtilData);

  // "gender" field.
  Gender? _gender;
  Gender get gender => _gender ?? Gender.unset;
  set gender(Gender? val) => _gender = val;

  bool hasGender() => _gender != null;

  // "weight" field.
  double? _weight;
  double get weight => _weight ?? 0.0;
  set weight(double? val) => _weight = val;

  void incrementWeight(double amount) => weight = weight + amount;

  bool hasWeight() => _weight != null;

  static UserBodyInfoStruct fromMap(Map<String, dynamic> data) =>
      UserBodyInfoStruct(
        gender: data['gender'] is Gender
            ? data['gender']
            : deserializeEnum<Gender>(data['gender']),
        weight: castToType<double>(data['weight']),
      );

  static UserBodyInfoStruct? maybeFromMap(dynamic data) => data is Map
      ? UserBodyInfoStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'gender': _gender?.serialize(),
        'weight': _weight,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'gender': serializeParam(
          _gender,
          ParamType.Enum,
        ),
        'weight': serializeParam(
          _weight,
          ParamType.double,
        ),
      }.withoutNulls;

  static UserBodyInfoStruct fromSerializableMap(Map<String, dynamic> data) =>
      UserBodyInfoStruct(
        gender: deserializeParam<Gender>(
          data['gender'],
          ParamType.Enum,
          false,
        ),
        weight: deserializeParam(
          data['weight'],
          ParamType.double,
          false,
        ),
      );

  @override
  String toString() => 'UserBodyInfoStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is UserBodyInfoStruct &&
        gender == other.gender &&
        weight == other.weight;
  }

  @override
  int get hashCode => const ListEquality().hash([gender, weight]);
}

UserBodyInfoStruct createUserBodyInfoStruct({
  Gender? gender,
  double? weight,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    UserBodyInfoStruct(
      gender: gender,
      weight: weight,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

UserBodyInfoStruct? updateUserBodyInfoStruct(
  UserBodyInfoStruct? userBodyInfo, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    userBodyInfo
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addUserBodyInfoStructData(
  Map<String, dynamic> firestoreData,
  UserBodyInfoStruct? userBodyInfo,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (userBodyInfo == null) {
    return;
  }
  if (userBodyInfo.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && userBodyInfo.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final userBodyInfoData =
      getUserBodyInfoFirestoreData(userBodyInfo, forFieldValue);
  final nestedData =
      userBodyInfoData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = userBodyInfo.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getUserBodyInfoFirestoreData(
  UserBodyInfoStruct? userBodyInfo, [
  bool forFieldValue = false,
]) {
  if (userBodyInfo == null) {
    return {};
  }
  final firestoreData = mapToFirestore(userBodyInfo.toMap());

  // Add any Firestore field values
  userBodyInfo.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getUserBodyInfoListFirestoreData(
  List<UserBodyInfoStruct>? userBodyInfos,
) =>
    userBodyInfos?.map((e) => getUserBodyInfoFirestoreData(e, true)).toList() ??
    [];

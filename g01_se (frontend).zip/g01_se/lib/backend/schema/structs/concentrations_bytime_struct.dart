// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ConcentrationsBytimeStruct extends FFFirebaseStruct {
  ConcentrationsBytimeStruct({
    /// time as seconds
    DateTime? time,

    /// concentration at specific time
    double? concentration,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _time = time,
        _concentration = concentration,
        super(firestoreUtilData);

  // "time" field.
  DateTime? _time;
  DateTime? get time => _time;
  set time(DateTime? val) => _time = val;

  bool hasTime() => _time != null;

  // "concentration" field.
  double? _concentration;
  double get concentration => _concentration ?? 0.0;
  set concentration(double? val) => _concentration = val;

  void incrementConcentration(double amount) =>
      concentration = concentration + amount;

  bool hasConcentration() => _concentration != null;

  static ConcentrationsBytimeStruct fromMap(Map<String, dynamic> data) =>
      ConcentrationsBytimeStruct(
        time: data['time'] as DateTime?,
        concentration: castToType<double>(data['concentration']),
      );

  static ConcentrationsBytimeStruct? maybeFromMap(dynamic data) => data is Map
      ? ConcentrationsBytimeStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'time': _time,
        'concentration': _concentration,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'time': serializeParam(
          _time,
          ParamType.DateTime,
        ),
        'concentration': serializeParam(
          _concentration,
          ParamType.double,
        ),
      }.withoutNulls;

  static ConcentrationsBytimeStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      ConcentrationsBytimeStruct(
        time: deserializeParam(
          data['time'],
          ParamType.DateTime,
          false,
        ),
        concentration: deserializeParam(
          data['concentration'],
          ParamType.double,
          false,
        ),
      );

  @override
  String toString() => 'ConcentrationsBytimeStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is ConcentrationsBytimeStruct &&
        time == other.time &&
        concentration == other.concentration;
  }

  @override
  int get hashCode => const ListEquality().hash([time, concentration]);
}

ConcentrationsBytimeStruct createConcentrationsBytimeStruct({
  DateTime? time,
  double? concentration,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    ConcentrationsBytimeStruct(
      time: time,
      concentration: concentration,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

ConcentrationsBytimeStruct? updateConcentrationsBytimeStruct(
  ConcentrationsBytimeStruct? concentrationsBytime, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    concentrationsBytime
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addConcentrationsBytimeStructData(
  Map<String, dynamic> firestoreData,
  ConcentrationsBytimeStruct? concentrationsBytime,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (concentrationsBytime == null) {
    return;
  }
  if (concentrationsBytime.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && concentrationsBytime.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final concentrationsBytimeData =
      getConcentrationsBytimeFirestoreData(concentrationsBytime, forFieldValue);
  final nestedData =
      concentrationsBytimeData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields =
      concentrationsBytime.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getConcentrationsBytimeFirestoreData(
  ConcentrationsBytimeStruct? concentrationsBytime, [
  bool forFieldValue = false,
]) {
  if (concentrationsBytime == null) {
    return {};
  }
  final firestoreData = mapToFirestore(concentrationsBytime.toMap());

  // Add any Firestore field values
  concentrationsBytime.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getConcentrationsBytimeListFirestoreData(
  List<ConcentrationsBytimeStruct>? concentrationsBytimes,
) =>
    concentrationsBytimes
        ?.map((e) => getConcentrationsBytimeFirestoreData(e, true))
        .toList() ??
    [];

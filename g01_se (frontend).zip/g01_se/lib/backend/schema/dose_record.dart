import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class DoseRecord extends FirestoreRecord {
  DoseRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "doseTimestamp" field.
  DateTime? _doseTimestamp;
  DateTime? get doseTimestamp => _doseTimestamp;
  bool hasDoseTimestamp() => _doseTimestamp != null;

  // "user" field.
  DocumentReference? _user;
  DocumentReference? get user => _user;
  bool hasUser() => _user != null;

  void _initializeFields() {
    _doseTimestamp = snapshotData['doseTimestamp'] as DateTime?;
    _user = snapshotData['user'] as DocumentReference?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('dose');

  static Stream<DoseRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => DoseRecord.fromSnapshot(s));

  static Future<DoseRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => DoseRecord.fromSnapshot(s));

  static DoseRecord fromSnapshot(DocumentSnapshot snapshot) => DoseRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static DoseRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      DoseRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'DoseRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is DoseRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createDoseRecordData({
  DateTime? doseTimestamp,
  DocumentReference? user,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'doseTimestamp': doseTimestamp,
      'user': user,
    }.withoutNulls,
  );

  return firestoreData;
}

class DoseRecordDocumentEquality implements Equality<DoseRecord> {
  const DoseRecordDocumentEquality();

  @override
  bool equals(DoseRecord? e1, DoseRecord? e2) {
    return e1?.doseTimestamp == e2?.doseTimestamp && e1?.user == e2?.user;
  }

  @override
  int hash(DoseRecord? e) =>
      const ListEquality().hash([e?.doseTimestamp, e?.user]);

  @override
  bool isValidKey(Object? o) => o is DoseRecord;
}

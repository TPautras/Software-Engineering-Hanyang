import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ConcentrationsRecord extends FirestoreRecord {
  ConcentrationsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "timestamp" field.
  DateTime? _timestamp;
  DateTime? get timestamp => _timestamp;
  bool hasTimestamp() => _timestamp != null;

  // "concentration" field.
  double? _concentration;
  double get concentration => _concentration ?? 0.0;
  bool hasConcentration() => _concentration != null;

  // "user" field.
  DocumentReference? _user;
  DocumentReference? get user => _user;
  bool hasUser() => _user != null;

  void _initializeFields() {
    _timestamp = snapshotData['timestamp'] as DateTime?;
    _concentration = castToType<double>(snapshotData['concentration']);
    _user = snapshotData['user'] as DocumentReference?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('concentrations');

  static Stream<ConcentrationsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ConcentrationsRecord.fromSnapshot(s));

  static Future<ConcentrationsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ConcentrationsRecord.fromSnapshot(s));

  static ConcentrationsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ConcentrationsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ConcentrationsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ConcentrationsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ConcentrationsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ConcentrationsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createConcentrationsRecordData({
  DateTime? timestamp,
  double? concentration,
  DocumentReference? user,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'timestamp': timestamp,
      'concentration': concentration,
      'user': user,
    }.withoutNulls,
  );

  return firestoreData;
}

class ConcentrationsRecordDocumentEquality
    implements Equality<ConcentrationsRecord> {
  const ConcentrationsRecordDocumentEquality();

  @override
  bool equals(ConcentrationsRecord? e1, ConcentrationsRecord? e2) {
    return e1?.timestamp == e2?.timestamp &&
        e1?.concentration == e2?.concentration &&
        e1?.user == e2?.user;
  }

  @override
  int hash(ConcentrationsRecord? e) =>
      const ListEquality().hash([e?.timestamp, e?.concentration, e?.user]);

  @override
  bool isValidKey(Object? o) => o is ConcentrationsRecord;
}

import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'feedback_widget.dart' show FeedbackWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class FeedbackModel extends FlutterFlowModel<FeedbackWidget> {
  ///  State fields for stateful widgets in this component.

  // State field(s) for effect widget.
  FocusNode? effectFocusNode;
  TextEditingController? effectTextController;
  String? Function(BuildContext, String?)? effectTextControllerValidator;
  // State field(s) for sideEffect widget.
  FocusNode? sideEffectFocusNode;
  TextEditingController? sideEffectTextController;
  String? Function(BuildContext, String?)? sideEffectTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    effectFocusNode?.dispose();
    effectTextController?.dispose();

    sideEffectFocusNode?.dispose();
    sideEffectTextController?.dispose();
  }
}

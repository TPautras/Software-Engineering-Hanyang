package com.mycompany.g01se

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
